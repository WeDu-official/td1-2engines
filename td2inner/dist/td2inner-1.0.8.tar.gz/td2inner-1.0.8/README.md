**TD2INNER** is an internal component in [Time_diffz](https://pypi.org/project/timediffz)
functionment